pdflatex poster.tex

rm *.aux *.nav *.out *.snm *.toc *.blg *.log *.lpr *~ 
